# GrantConnect

A professional, transparent grant-opportunity portal starter.

## Files
- `index.html` — landing page and grant listings
- `apply.html` — starter application form
- `styles.css` — responsive styling

This is a front-end starter. Connect a legitimate grant provider, database, authentication, and documented payment process before using it for real applications.
